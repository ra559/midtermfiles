# All files Sorted
## Image Files
1 user group  91K Nov  1  2020 file.jpg
1 user group  85K Feb 11  2019 file.png
## PDF Files
1 user group 3.0K Dec 14 15:11 file-copy.pdf
1 user group 3.0K Dec 14 15:11 file.pdf
## Log files
1 user group  910 Dec 14 15:09 file.log
1 user group  910 Dec 14 15:08 file.log
## Scripts
1 user group   33 Dec 14 15:12 file.sh
1 user group   33 Dec 14 15:12 file.sh
