#!/bin/bash
echo "i am a script"
